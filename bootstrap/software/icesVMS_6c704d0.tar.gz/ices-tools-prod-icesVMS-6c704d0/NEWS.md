# icesVMS 1.0.0.9013

* bugfix in get_logbook()


# icesVMS 1.0.0.9012

* add get_logbook() to download logbook data


# icesVMS 1.0.0.9011

* fixing bugs in url construction


# icesVMS 1.0.0.9010

*  bug fixes


# icesVMS 1.0.0.9009

*  improved  get and add arg - metier_level4 to get_passive_footprint()


# icesVMS 1.0.0.9008

* add get_passive_footprint()


# icesVMS 1.0.0.9007

* add nyears argument to get_sar_map()


# icesVMS 1.0.0.9006

* add get_wgfbit_data2()


# icesVMS 1.0.0.9005

* added function get_wgfbit_data1()
* add get_sar_map() function


# icesVMS 1.0.0.9004

* add get_fo_landings()


# icesVMS 1.0.0.9003

* add get_effort_map() function


# icesVMS 1.0.0.9002

* add get_fo_effort() fisheries overviews effort function
* add get_square() function


# icesVMS 1.0.0.9001

* write jwt.token to tempdir
* add filtering args to get_vms() function


# icesVMS 1.0.0.9000

- Internal changes only.


